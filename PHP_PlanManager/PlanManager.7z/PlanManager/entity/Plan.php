<?
    //任务对象
    class Plan{
        public $plan_name ;
        public  $budgetDate = 0;
        public  $plan_id = 0;
        public  $plan_state;
        public $plan_info;
        public $closing_date;
        public $plan_leve;
    }
?>