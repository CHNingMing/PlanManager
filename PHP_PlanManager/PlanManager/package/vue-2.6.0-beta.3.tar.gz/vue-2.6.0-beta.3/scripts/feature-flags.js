module.exports = {
  NEW_SLOT_SYNTAX: true
}
