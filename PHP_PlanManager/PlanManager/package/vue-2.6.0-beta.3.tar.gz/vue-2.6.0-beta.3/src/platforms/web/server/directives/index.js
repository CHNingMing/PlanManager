import show from './show'
import model from './model'

export default {
  show,
  model
}
